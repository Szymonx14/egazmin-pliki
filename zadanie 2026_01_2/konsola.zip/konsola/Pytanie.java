public abstract class Pytanie {
    protected String tekst, zdjece;
    protected boolean czyPoprawna;

    public Pytanie(String tekst, String zdjece) {
        this.tekst = tekst;
        this.zdjece = zdjece;
        this.czyPoprawna = false;
    }

    public abstract boolean sprawdzOdpowiedz(char znak);

}
