public class PytanieZamkniete extends Pytanie {
    private String tescA, trescB, trescC;
    private char poprawnaOdpowiedz;

    public PytanieZamkniete(String tekst, String zdjece, String tescA, String trescB, String trescC, char poprawnaOdpowiedz) {
        super(tekst, zdjece);
        this.tescA = tescA;
        this.trescB = trescB;
        this.trescC = trescC;
        this.poprawnaOdpowiedz = poprawnaOdpowiedz;
    }

    @Override
    public boolean sprawdzOdpowiedz(char znak) {
        if (znak == poprawnaOdpowiedz){
            czyPoprawna = true;
        }
        else {
            czyPoprawna = false;
        }
        return czyPoprawna;
    }


}
